#ifndef LABPZRL1_FUNCS_H
#define LABPZRL1_FUNCS_H

double* readArray(int arrayLen);
void selectionSort(double* array, int arrayLen);
void printArray(double* array, int arrayLen);

#endif //LABPZRL1_FUNCS_H
