#include <stdio.h>
#include <stdlib.h>
#include "funcs.h"
#include <string.h>

int main() {
    int arrayLen;
    scanf("%d", &arrayLen);
    if (arrayLen < 0) {
        printf("Error");
        return -1;
    }

    double *array = readArray(arrayLen);
    selectionSort(array, arrayLen);
    printArray(array, arrayLen);

    free(array);
    return 0;
}
