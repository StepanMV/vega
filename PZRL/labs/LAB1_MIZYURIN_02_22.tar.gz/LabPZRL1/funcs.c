#include <stdio.h>
#include <stdlib.h>
#include "funcs.h"

double *readArray(int arrayLen) {
    double *array = (double *) malloc(arrayLen * sizeof(double));
    for (int i = 0; i < arrayLen; ++i) {
        scanf("%lf", &array[i]);
    }
    return array;
}

void selectionSort(double *array, int arrayLen) {
    for (int i = 0; i < arrayLen; ++i) {
        int iMin = 0;
        for (int j = 0; j < arrayLen - i; ++j) {
            if (array[j] < array[iMin]) {
                iMin = j;
            }
        }
        double temp = array[arrayLen - 1 - i];
        array[arrayLen - 1 - i] = array[iMin];
        array[iMin] = temp;
    }
}

void printArray(double *array, int arrayLen) {
    for (int i = 0; i < arrayLen; ++i) {
        printf("%lf ", array[i]);
    }
    printf("\n");
}